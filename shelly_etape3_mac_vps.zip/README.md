# Shelly Data Collector — Étape 3 : Mac → VPS via SSH

Projet Python compatible avec **Python 3.8 (Mac Catalina)** et **Python 3.11 (VPS Debian 12)**. Aucune bibliothèque externe, aucun service exposé sur Internet, aucune tâche automatique installée à cette étape.

## Principe

1. Le **Mac** collecte les Shelly en local dans `data/local.sqlite3` (`make collect DAYS=7`, déjà réalisé).
2. `make sync VPS=...` crée une **sauvegarde SQLite cohérente** (API `sqlite3.backup`), distincte de la base en cours d'utilisation.
3. Le Mac transfère la sauvegarde par **SCP/SSH** au VPS, qui vérifie son **SHA-256** et la cohérence SQLite.
4. Le **VPS** importe les appareils, mesures, états quotidiens et blocs suspects dans `data/central.sqlite3` en **une transaction SQLite**, sans doublons.
5. Le VPS exporte les tableaux CSV dans `data/exports-vps/` avec `make export-vps`.
6. Après import confirmé, le fichier temporaire distant est supprimé. Le Mac conserve sa base, même si la connexion SSH échoue.

**Important :** synchroniser ne réinterroge jamais les Shelly. La collecte automatique quotidienne sera ajoutée seulement dans une étape ultérieure.

## A. Installation sur le Mac

Dans `~/Documents/shelly` :

1. Sauvegarder le projet existant, surtout **`data/local.sqlite3`**, avant de remplacer les scripts.
2. Décompresser l'archive et copier les fichiers du projet dans le dossier existant. **Ne pas supprimer `data/`**.
3. Dans le terminal local de VS Code :

```bash
cd ~/Documents/shelly
make test
make stats
```

Résultat attendu de la base actuelle : `devices : 3`, `history_records : 40323`, `daily_snapshots : 3`, `suspect_blocks : 0` (tant que tu n'as pas réalisé de nouvelles collectes).

## B. Prérequis SSH

Il faut pouvoir se connecter depuis le Mac au VPS avec **une clé SSH**. Le script refuse un mot de passe interactif (`BatchMode=yes`) pour pouvoir fonctionner sans blocage lorsqu'il sera automatisé.

Si ton VPS possède déjà un alias dans `~/.ssh/config`, utilise cet alias ; sinon utilise `dev@IP_PUBLIQUE_OU_DOMAINE`. L'hostname interne `vps-1148726b` n'est pas nécessairement accessible depuis le Mac.

Teste **manuellement** la connexion SSH sur ton Mac (remplacer `mon-vps` par l'alias ou `dev@...`) :

```bash
ssh mon-vps 'echo SSH_OK'
ssh -o BatchMode=yes mon-vps 'echo SSH_OK'
```

La première connexion peut demander la confirmation de l'empreinte de la clé hôte. **Vérifier cette empreinte par une source de confiance avant d'accepter.** Si la seconde commande échoue, configurer d'abord l'authentification par clé SSH. Ne pas désactiver la vérification de la clé hôte (`StrictHostKeyChecking`).

## C. Installer les mêmes scripts sur le VPS

Le projet du VPS existe déjà sous `/home/dev/shelly`. Depuis le **terminal Mac** placé dans le projet :

```bash
scp -r src tests config Makefile README.md mon-vps:/home/dev/shelly/
```

Cela **ne copie pas** `data/local.sqlite3` et ne touche pas aux données existantes du VPS. Cela transmet seulement les scripts, les tests et la configuration des modèles. Sur un VPS où ces fichiers ont été personnalisés, faire un diff/commit préalable.

Depuis le **terminal SSH du VPS** :

```bash
cd /home/dev/shelly
make test
```

## D. Première synchronisation manuelle

Sur le Mac :

```bash
cd ~/Documents/shelly
make sync VPS=mon-vps
```

Cette commande **ne contacte aucun Shelly**. Elle sauvegarde la base existante, copie les octets via SCP puis lance l'import sur le VPS. Si le transfert ou l'import échoue, elle affiche une erreur et conserve la base Mac. La commande peut être relancée.

Ensuite sur le **VPS** :

```bash
cd /home/dev/shelly
make stats-vps
make export-vps
ls -lh data/central.sqlite3 data/exports-vps/*.csv
```

Résultat attendu au premier transfert de la base actuelle : **40 323 mesures**, **3 appareils**, **3 snapshots**. La colonne `history_changed` dans le message d'import compte les lignes nouvelles *ou corrigées* (pas nécessairement le total de lignes après plusieurs imports).

## E. Test anti-doublons

Relancer la même synchronisation sur le Mac :

```bash
make sync VPS=mon-vps
```

Puis sur le VPS :

```bash
make stats-vps
```

Le total doit rester à **40 323** mesures tant qu'aucune nouvelle collecte n'a été effectuée. Le contrôle de reprise et les clés primaires empêchent d'ajouter des doublons.

## Autres commandes

| Terminal | Commande | Effet |
|---|---|---|
| Mac | `make list` | Liste les appareils configurés |
| Mac | `make audit` | Inspecte les capacités de lecture sans enregistrer d'historique |
| Mac | `make collect DAYS=7` | Interroge les Shelly et actualise la base locale |
| Mac | `make history DAYS=7` | Récupère uniquement les historiques disponibles |
| Mac | `make backfill` | Récupère les blocs historiques valides disponibles (potentiellement long) |
| Mac | `make stats` | Statistiques de la base locale |
| Mac | `make export` | Export local CSV |
| Mac | `make sync VPS=mon-vps` | Sauvegarde et synchronise la base vers le VPS |
| VPS | `make stats-vps` | Statistiques de la base centrale |
| VPS | `make export-vps` | Exports CSV depuis la base centrale |
| VPS | `make import SOURCE=/chemin/lot.sqlite3 SHA256=...` | Import manuel d'un lot SQLite déjà reçu (usage avancé) |
| Mac ou VPS | `make test` | Tests indépendants des appareils |

## Garantie de déduplication

- Chaque mesure conserve la clé primaire `(device_id, channel, timestamp_utc, period_s)`.
- Un même fichier a son empreinte SHA-256 mémorisée dans `sync_imports` : un import identique est ignoré.
- Quand une nouvelle sauvegarde reprend des mesures déjà importées, une mesure identique n'est pas réécrite ; une valeur corrigée par le Shelly peut mettre à jour la ligne, sans doublon.
- Les snapshots conservent au maximum un état par jour local et par appareil.
- Un échec d'import SQL déclenche `ROLLBACK`. Le Mac ne supprime pas sa base et une nouvelle tentative est possible.

La protection suppose **une source Mac de référence** : éviter d'importer dans un ordre arbitraire de vieilles sauvegardes contenant d'anciennes valeurs corrigées.

## Données sensibles et sécurité

- La base peut contenir les identifiants matériels, noms de réseau, adresses IP et états des appareils. Protéger `data/` sur les deux machines.
- Les transferts sont chiffrés par SSH ; **aucun port HTTP, SQLite ou Shelly n'est ouvert sur Internet**.
- `data/` est exclu de Git et **n'est pas inclus dans l'archive fournie**.
- Des sauvegardes régulières de `data/central.sqlite3` devront être définies avant automatisation.
- Une machine Mac totalement éteinte ne peut pas collecter les états manquants non historisés. Les historiques internes des compteurs permettent un rattrapage dans leur limite de rétention.
- Le module de synchronisation utilise les chemins du VPS déjà connus : `/home/dev/shelly` et `data/central.sqlite3`.

## Prochaine étape, après validation

Ajouter un `launchd` sur Mac qui effectue **au maximum une collecte quotidienne**, contrôle les journées manquantes puis `make sync` lorsque le Mac est en ligne. **Aucune planification n'est activée par ce kit.**

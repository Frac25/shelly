"""Shelly Data Collector : collecte locale et synchronisation VPS par SSH."""
__version__ = "0.3.0"

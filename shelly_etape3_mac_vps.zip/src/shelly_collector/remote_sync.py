"""Création d'un snapshot SQLite cohérent et envoi par SSH/SCP depuis le Mac.

Compatible macOS Catalina et Python 3.8, sans dépendances additionnelles.
"""
import hashlib
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import tempfile

from .sync_import import open_readonly, sha256_file, validate_source

REMOTE_ROOT = "/home/dev/shelly"
TARGET_RE = re.compile(r"^[a-zA-Z0-9_][a-zA-Z0-9_.-]*(?:@[a-zA-Z0-9_][a-zA-Z0-9_.-]*)?$")


def backup_database(local_db, output_file):
    if not Path(local_db).is_file():
        raise ValueError("Base Mac introuvable : {}. Lancer make collect d'abord.".format(local_db))
    source = open_readonly(local_db)
    try:
        validate_source(source)
        target = sqlite3.connect(str(output_file))
        try:
            source.backup(target)  # cohérent même si la base source est en mode WAL
        finally:
            target.close()
    finally:
        source.close()


def run_command(argv):
    print("Exécution : {}".format(" ".join(argv[:3]) + (" ..." if len(argv) > 3 else "")), flush=True)
    subprocess.run(argv, check=True)


def sync_to_vps(local_db, target):
    if not TARGET_RE.fullmatch(target or "") or target.startswith("-"):
        raise ValueError("Cible SSH incorrecte : utiliser un alias SSH ou dev@hote")
    inbox = REMOTE_ROOT + "/data/inbox"
    ssh_base = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", target]
    with tempfile.TemporaryDirectory(prefix="shelly-sync-") as folder:
        snapshot = Path(folder) / "shelly-snapshot.sqlite3"
        print("Création d'une sauvegarde SQLite cohérente...")
        backup_database(local_db, snapshot)
        digest = sha256_file(snapshot)
        final = inbox + "/" + digest + ".sqlite3"
        tmp = final + ".part-" + str(os.getpid())
        print("Sauvegarde : {} octets | SHA-256 : {}".format(snapshot.stat().st_size, digest))
        print("Préparation du dossier distant...")
        run_command(ssh_base + ["mkdir -p " + inbox + " && chmod 700 " + inbox])
        print("Transfert chiffré vers le VPS...")
        run_command(["scp", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
                     str(snapshot), target + ":" + tmp])
        print("Import atomique dans la base centrale...")
        remote = (
            "mv -f " + tmp + " " + final + " && chmod 600 " + final +
            " && cd " + REMOTE_ROOT +
            " && PYTHONPATH=src python3 -m shelly_collector.cli import-snapshot" +
            " --source " + final + " --sha256 " + digest +
            " --db data/central.sqlite3" +
            " && rm -f " + final
        )
        run_command(ssh_base + [remote])
        print("Synchronisation confirmée par le VPS.")
    return digest

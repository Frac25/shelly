"""Importation idempotente sur le VPS d'une sauvegarde SQLite créée sur Mac.

Aucun port de base de données n'est exposé : l'import est lancé par SSH.
"""
import hashlib
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

from .storage import connect


IMPORT_SCHEMA = """
CREATE TABLE IF NOT EXISTS sync_imports (
    sha256 TEXT PRIMARY KEY,
    imported_at_utc TEXT NOT NULL,
    devices_count INTEGER NOT NULL,
    history_changed INTEGER NOT NULL,
    snapshots_added INTEGER NOT NULL,
    suspects_added INTEGER NOT NULL
);
"""
REQUIRED_TABLES = {"devices", "history", "snapshots", "suspect_blocks"}


def sha256_file(filename):
    sha = hashlib.sha256()
    with open(filename, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(chunk)
    return sha.hexdigest()


def open_readonly(filename):
    path = Path(filename).expanduser().resolve()
    if not path.is_file():
        raise ValueError("Fichier source introuvable : {}".format(path))
    # quote() protège les espaces, # et ? dans les chemins.
    uri = "file:{}?mode=ro".format(quote(str(path), safe="/"))
    return sqlite3.connect(uri, uri=True, timeout=20)


def validate_source(src):
    tables = {row[0] for row in src.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if not REQUIRED_TABLES.issubset(tables):
        raise ValueError("Source incompatible, tables absentes : {}".format(
            ", ".join(sorted(REQUIRED_TABLES - tables))))
    status = src.execute("PRAGMA quick_check").fetchone()
    if not status or status[0] != "ok":
        raise ValueError("La sauvegarde SQLite source a échoué au contrôle d'intégrité")


def _stream_copy(src, dst, select_sql, insert_sql, batch_size=2000):
    count = 0
    cur = src.execute(select_sql)
    while True:
        rows = cur.fetchmany(batch_size)
        if not rows:
            break
        result = dst.executemany(insert_sql, rows)
        count += result.rowcount if result.rowcount >= 0 else 0
    return count


def import_snapshot(source, destination, expected_sha256=None):
    """Import atomique et réexécutable. Renvoie les statistiques du lot."""
    actual_sha256 = sha256_file(source)
    if expected_sha256 and actual_sha256 != expected_sha256.lower():
        raise ValueError("SHA-256 incorrect : le transfert est incomplet ou altéré")
    if Path(source).resolve() == Path(destination).resolve():
        raise ValueError("La base source ne doit pas être la destination")
    src = open_readonly(source)
    try:
        validate_source(src)
        dst = connect(destination)
        try:
            dst.executescript(IMPORT_SCHEMA)
            dst.execute("BEGIN IMMEDIATE")
            try:
                done = dst.execute("SELECT 1 FROM sync_imports WHERE sha256=?",
                                   (actual_sha256,)).fetchone()
                if done:
                    dst.commit()
                    return {"sha256": actual_sha256, "already_imported": True,
                            "devices": 0, "history_changed": 0,
                            "snapshots_added": 0, "suspects_added": 0}
                devices = _stream_copy(src, dst,
                    "SELECT device_id, alias, model, last_seen_utc FROM devices",
                    """INSERT INTO devices(device_id, alias, model, last_seen_utc)
                       VALUES (?, ?, ?, ?)
                       ON CONFLICT(device_id) DO UPDATE SET
                         alias=excluded.alias, model=excluded.model,
                         last_seen_utc=CASE WHEN excluded.last_seen_utc > devices.last_seen_utc
                             THEN excluded.last_seen_utc ELSE devices.last_seen_utc END""")
                history = _stream_copy(src, dst,
                    "SELECT device_id, channel, timestamp_utc, period_s, values_json FROM history",
                    """INSERT INTO history(device_id,channel,timestamp_utc,period_s,values_json)
                       VALUES (?,?,?,?,?)
                       ON CONFLICT(device_id,channel,timestamp_utc,period_s)
                       DO UPDATE SET values_json=excluded.values_json
                       WHERE history.values_json <> excluded.values_json""")
                snapshots = _stream_copy(src, dst,
                    "SELECT device_id, local_day, captured_at_utc, status_json FROM snapshots",
                    """INSERT OR IGNORE INTO snapshots
                       (device_id,local_day,captured_at_utc,status_json) VALUES (?,?,?,?)""")
                suspects = _stream_copy(src, dst,
                    "SELECT device_id,channel,timestamp_utc,period_s,records,reason FROM suspect_blocks",
                    """INSERT OR IGNORE INTO suspect_blocks
                       (device_id,channel,timestamp_utc,period_s,records,reason)
                       VALUES (?,?,?,?,?,?)""")
                dst.execute("""INSERT INTO sync_imports
                  (sha256, imported_at_utc, devices_count, history_changed,
                   snapshots_added, suspects_added) VALUES (?,?,?,?,?,?)""",
                  (actual_sha256, datetime.now(timezone.utc).isoformat(),
                   devices, history, snapshots, suspects))
                dst.commit()
            except Exception:
                dst.rollback()
                raise
            return {"sha256": actual_sha256, "already_imported": False,
                    "devices": devices, "history_changed": history,
                    "snapshots_added": snapshots, "suspects_added": suspects}
        finally:
            dst.close()
    finally:
        src.close()

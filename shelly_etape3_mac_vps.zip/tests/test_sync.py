import sqlite3
import tempfile
import unittest
from pathlib import Path

from shelly_collector.storage import connect, register_device, save_samples, save_snapshot, save_suspect, stats
from shelly_collector.remote_sync import backup_database
from shelly_collector.sync_import import import_snapshot, sha256_file


class TestSync(unittest.TestCase):
    def test_mac_to_vps_idempotent_and_corrections(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            mac = root / "mac.sqlite3"
            backup = root / "backup.sqlite3"
            backup2 = root / "backup2.sqlite3"
            vps = root / "central.sqlite3"
            conn = connect(mac)
            device_id = register_device(conn, {"id": "shelly-a", "model": "EMG3"}, "em_gen3", "2026-11-19T14:00:00Z")
            self.assertEqual(save_samples(conn, device_id, 0, [
                (1795000000, 60, {"energy": 1}), (1795000060, 60, {"energy": 2})]), 2)
            self.assertTrue(save_snapshot(conn, device_id, "2026-11-19", "2026-11-19T14:00:00Z", {"a": 1}))
            save_suspect(conn, device_id, 0, {"ts": 946684800, "period":60, "records":1}, "date suspecte")
            backup_database(mac, backup)
            h = sha256_file(backup)
            result = import_snapshot(backup, vps, h)
            self.assertEqual(result["history_changed"], 2)
            self.assertEqual(result["snapshots_added"], 1)
            self.assertEqual(result["suspects_added"], 1)
            self.assertTrue(import_snapshot(backup, vps, h)["already_imported"])
            with self.assertRaises(ValueError):
                import_snapshot(backup, vps, "0" * 64)
            # Même clé, valeur corrigée + une nouvelle mesure : jamais de doublons.
            save_samples(conn, device_id, 0, [
                (1795000060, 60, {"energy": 9}), (1795000120, 60, {"energy": 3})])
            backup_database(mac, backup2)
            self.assertEqual(import_snapshot(backup2, vps)["history_changed"], 2)
            check = connect(vps)
            self.assertEqual(stats(check)["history_records"], 3)
            self.assertEqual(stats(check)["daily_snapshots"], 1)
            self.assertEqual(stats(check)["suspect_blocks"], 1)
            value = check.execute("SELECT values_json FROM history WHERE timestamp_utc=1795000060").fetchone()[0]
            self.assertIn('"energy":9', value)
            check.close()
            conn.close()

    def test_missing_source_and_bad_file(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            with self.assertRaises(ValueError):
                backup_database(folder/"missing.sqlite3", folder/"target.sqlite3")
            fake = folder/"fake.sqlite3"
            fake.write_text("not a database")
            with self.assertRaises((sqlite3.DatabaseError, ValueError)):
                import_snapshot(fake, folder/"central.sqlite3")


if __name__ == "__main__":
    unittest.main()
